<?php

namespace App\Http\Controllers\Backend;

use App\Http\Controllers\Controller;
use App\Models\Slider;
use Illuminate\Http\Request;

class SliderController extends Controller
{
   public function index(){
       $sliders = Slider::all();
       return view('backend.slider.index',compact('sliders'));
   }


    public function create(){
        return view('backend.slider.create');
    }


    public function store(Request $request)
    {
        $this->validate($request,[
            'photo' => 'required|image',
        ]);
//        try {
//            $request->validate([
//
//                'photo' => 'required|image ',
//            ]);

            $newName = 'slider_' . time() . '.' . $request->file('photo')->getClientOriginalExtension();
            $request->photo->move('uploads/slider/', $newName);
            $sliderdata = [

                'photo' => $newName
            ];
            Slider::create($sliderdata);
            return redirect()->route('admin.slider');
//        } catch (\Exception $exception) {
//            $errors = $exception->validator->getMessageBag();
//            return redirect()->back()->withErrors($errors)->withInput();
//        }

    }



}
