@extends('layouts.frontend')

@section('main')
    <div class="container">
        <div class="col-md-12" style="min-height: 600px;">
            <div class="col-md-5 float-left">
                <h1>Login</h1><hr>
                <form action="{{route('login')}}" method="post">
{{--                    @if (\Illuminate\Support\Facades\Session::has('message'))--}}
{{--                        <p class="alert alert-warning alert-dismissible fade show">{{\Illuminate\Support\Facades\Session::get('message')}}</p>--}}
{{--                    @endif--}}
                    @csrf
                    <div class="form-group">
                        <label class="col-form-label">Email</label>
                        <input type="text" name="email" class="form-control">
                    </div>

                    <div class="form-group">
                        <label class="col-form-label">Password</label>
                        <input type="password" name="password"  class="form-control" id="password1" >
                    </div>

                    <div class="right-w3l">
                        <input type="submit" class="form-control" value="Login">
                    </div>

                </form>
            </div>

            <div class="col-md-6 float-right " style="">
                <h1>Register</h1><hr>
                <form action="{{route('register')}}" method="post">
                    @if ($errors->any())
                        <div class="alert alert-danger">
                            <ul>
                                @foreach ($errors->all() as $error)
                                    <li>{{ $error }}</li>
                                @endforeach
                            </ul>
                        </div>
                    @endif
                    @csrf
                    <div class="form-group">
                        <label class="col-form-label">Name</label>
                        <input type="text" name="name" class="form-control">
                    </div>

                    <div class="form-group">
                        <label class="col-form-label">Email</label>
                        <input type="text" name="email"  class="form-control">
                    </div>

                    <div class="form-group">
                        <label class="col-form-label">Phone</label>
                        <input type="text" name="phone" class="form-control">
                    </div>


                    <div class="form-group">
                        <label class="col-form-label">Address</label>
                        <textarea class="form-control" name="address"></textarea>
                    </div>

                    <div class="form-group">
                        <label class="col-form-label">Password</label>
                        <input type="password" name="password"  class="form-control" id="password1" >
                    </div>

                    <div class="right-w3l">
                        <input type="submit" class="form-control" value="Register">
                    </div>

                </form>
            </div>



        </div>
    </div>


@endsection
