@extends('layouts.backend')

@section('main')


    <div class="container mt-3">
        <h2 class="text-center">Admin Profile</h2>
        <div class="col-md-3">
            <img src="{{asset('uploads/users/'.auth()->user()->photo)}}">
        </div>
        <div class="col-md-8">
        <form action="#" method="post" enctype="multipart/form-data">
            @csrf
            <div class="mb-3">
                <label for="name" class="form-label">Name</label>
                <input type="text" class="form-control @error('name') is-invalid @enderror" name="name"
                       id="name" value="{{auth()->user()->name}}">
            </div>
            <div class="mb-3">
                <label for="email" class="form-label">Role</label>
                <input type="" class="form-control @error('email') is-invalid @enderror" name="email"
                       id="email" value="{{auth()->user()->role}}">
            </div>
            <div class="mb-3">
                <label for="phone" class="form-label">Phone</label>
                <input type="text" class="form-control @error('phone') is-invalid @enderror" name="phone"
                       id="phone" value="{{auth()->user()->phone}}">
            </div>

            <div class="mb-3">
                <label for="email" class="form-label">Email</label>
                <input type="email" class="form-control @error('email') is-invalid @enderror" name="email"
                       id="email" value="{{auth()->user()->email}}">
            </div>

            <div class="mb-3">
                <label for="address" class="form-label">Address</label>
                <textarea class="form-control @error('address') is-invalid @enderror" name="address"
                          id="address">{{auth()->user()->address}}</textarea>
            </div>


            <button type="submit" class="btn btn-primary">Submit</button>
        </form>
        </div>

    </div>


@endsection
