@extends('layouts.frontend')

@section('main')
    <div class="container" style="min-height: 800px;">
        <div class="col-md-2 float-left"></div>
        <div class="col-md-8 float-left" >
            <h1 style="text-align: center">Profile</h1><hr>
            <form action="{{route('user.profile')}}" method="post" enctype="multipart/form-data">

                @csrf

                <div class="form-group">
                   <img src="{{asset('uploads/users/'.auth()->user()->photo)}}" width="100px;">
                </div>

                <div class="form-group">
                    <label class="col-form-label">Name</label>
                    <input type="text" name="name" class="form-control" value="{{auth()->user()->name}}">
                </div>

                <div class="form-group">
                    <label class="col-form-label">Email</label>
                    <input type="text" name="email"  class="form-control" value="{{auth()->user()->email}}">
                </div>

                <div class="form-group">
                    <label class="col-form-label">Phone</label>
                    <input type="text" name="phone" class="form-control" value="{{auth()->user()->phone}}">
                </div>


                <div class="form-group">
                    <label class="col-form-label">Address</label>
                    <textarea class="form-control" name="address">{{auth()->user()->address}}</textarea>
                </div>

                <div class="form-group">
                    <label class="col-form-label">Photo</label>
                    <input type="file" name="photo"  class="form-control" id="photo" >
                </div>

{{--                <div class="form-group">--}}
{{--                    <label class="col-form-label">Password</label>--}}
{{--                    <input type="password" name="password"  class="form-control" id="password1" >--}}
{{--                </div>--}}

                <div class="right-w3l">
                    <input type="submit" class="form-control" value="Update Profile">
                </div>

            </form>
        </div>
        <div class="col-md-2 float-left"></div>
    </div>


@endsection
