<?php $__env->startSection('main'); ?>
    <div class="container">
        <div class="col-md-12" style="min-height: 600px;">

        <div class="col-md-5 float-left">
            <h1>Log In</h1><hr>
            <form action="#" method="post">
                <div class="form-group">
                    <label class="col-form-label">Username</label>
                    <input type="text" class="form-control" placeholder=" " name="Name" required="">
                </div>
                <div class="form-group">
                    <label class="col-form-label">Password</label>
                    <input type="password" class="form-control" placeholder=" " name="Password" required="">
                </div>
                <div class="right-w3l">
                    <input type="submit" class="form-control" value="Log in">
                </div>
                <div class="sub-w3l">
                    <div class="custom-control custom-checkbox mr-sm-2">
                        <input type="checkbox" class="custom-control-input" id="customControlAutosizing">
                        <label class="custom-control-label" for="customControlAutosizing">Remember me?</label>
                    </div>
                </div>
                <p class="text-center dont-do mt-3">Don't have an account?
                    <a href="#" data-toggle="modal" data-target="#exampleModal2">
                        Register Now</a>
                </p>
            </form>
        </div>


            <div class="col-md-6 float-right" style="">
                <h1>Register</h1><hr>
                <form action="<?php echo e(route('register')); ?>" method="post">
                    <div class="form-group">
                        <label class="col-form-label">Name</label>
                        <input type="text" class="form-control" placeholder=" " name="name" >
                    </div>

                    <div class="form-group">
                        <label class="col-form-label">Email</label>
                        <input type="text" class="form-control" placeholder=" " name="email" >
                    </div>

                    <div class="form-group">
                        <label class="col-form-label">Phone</label>
                        <input type="text" class="form-control" placeholder=" " name="phone" >
                    </div>


                    <div class="form-group">
                        <label class="col-form-label">Address</label>
                        <textarea class="form-control" name="address"></textarea>
                    </div>

                    <div class="form-group">
                        <label class="col-form-label">Password</label>
                        <input type="password" class="form-control" placeholder=" " name="password" id="password1" >
                    </div>
                    
                    
                    
                    
                    <div class="right-w3l">
                        <input type="submit" class="form-control" value="Register">
                    </div>
        
        
        
        
        
        
                </form>
            </div>



        </div>
    </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\php Server 2021\htdocs\laravel 2021\laravel_project\laravel\resources\views/frontend/register.blade.php ENDPATH**/ ?>