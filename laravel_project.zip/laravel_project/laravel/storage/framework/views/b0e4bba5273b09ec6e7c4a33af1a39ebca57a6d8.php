<?php $__env->startSection('main'); ?>
    <div class="container">
        <div class="col-md-12" style="min-height: 600px;">
            <div class="col-md-5 float-left">
                <h1>Login</h1><hr>
                <form action="<?php echo e(route('login')); ?>" method="post">



                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <label class="col-form-label">Email</label>
                        <input type="text" name="email" class="form-control">
                    </div>

                    <div class="form-group">
                        <label class="col-form-label">Password</label>
                        <input type="password" name="password"  class="form-control" id="password1" >
                    </div>

                    <div class="right-w3l">
                        <input type="submit" class="form-control" value="Login">
                    </div>

                </form>
            </div>

            <div class="col-md-6 float-right " style="">
                <h1>Register</h1><hr>
                <form action="<?php echo e(route('register')); ?>" method="post">
                    <?php if($errors->any()): ?>
                        <div class="alert alert-danger">
                            <ul>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    <?php endif; ?>
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <label class="col-form-label">Name</label>
                        <input type="text" name="name" class="form-control">
                    </div>

                    <div class="form-group">
                        <label class="col-form-label">Email</label>
                        <input type="text" name="email"  class="form-control">
                    </div>

                    <div class="form-group">
                        <label class="col-form-label">Phone</label>
                        <input type="text" name="phone" class="form-control">
                    </div>


                    <div class="form-group">
                        <label class="col-form-label">Address</label>
                        <textarea class="form-control" name="address"></textarea>
                    </div>

                    <div class="form-group">
                        <label class="col-form-label">Password</label>
                        <input type="password" name="password"  class="form-control" id="password1" >
                    </div>

                    <div class="right-w3l">
                        <input type="submit" class="form-control" value="Register">
                    </div>

                </form>
            </div>



        </div>
    </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\php Server 2021\htdocs\laravel 2021\laravel_project\laravel\resources\views/auth/register.blade.php ENDPATH**/ ?>