<?php $__env->startSection('main'); ?>

    <div class="container mt-3">
        <h2 class="text-center">Products List</h2>
        <a href="<?php echo e(route('admin.product.create')); ?>" class="btn btn-success">Create new product</a>
        <table class="table">
            <thead>
            <tr>
                <th scope="col">#</th>
                <th scope="col">Product Name</th>
                <th scope="col">Price</th>
                <th scope="col">Description</th>
                <th scope="col">Photo</th>
                <th scope="col">Action</th>
            </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <th scope="row"><?php echo e($key+1); ?></th>
                    <td><?php echo e($product->name); ?></td>
                    <td><?php echo e($product->price); ?> BDT</td>
                    <td><?php echo e($product->desc); ?></td>
                    <td>
                        <img src="<?php echo e(asset('uploads/products/'.$product->photo)); ?>" alt="" height="50px">
                    </td>
                    <td>
                        <a href="<?php echo e(route('admin.product.edit',$product->id)); ?>" class="btn btn-primary">Edit</a>
                        <a href="<?php echo e(route('admin.product.delete',$product->id)); ?>" class="btn btn-warning">Delete</a>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </tbody>
        </table>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\php Server 2021\htdocs\laravel 2021\laravel_project\bt106\resources\views/backend/products/index.blade.php ENDPATH**/ ?>